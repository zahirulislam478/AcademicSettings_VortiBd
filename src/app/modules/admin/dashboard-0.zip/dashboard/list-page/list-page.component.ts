/** @format */
import { Component, ViewEncapsulation } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Router } from "@angular/router";
import ConstantNames from "app/Urlconfig/constantNames";
import Utils from "app/Utility/utils";
import { isEmpty } from "lodash-es";
import { distinctUntilChanged } from "rxjs";
import { Dummy_Pair, FormParam_Interface } from "../dashboard.data";
import { DashboardService } from "../dashboard.service";

@Component({
  selector: "app-list-page",
  templateUrl: "./list-page.component.html",
  styleUrls: ["./list-page.component.scss"],
  encapsulation: ViewEncapsulation.None,
})

export class DashboardListPageComponent {
  appData = [
    {
      id: "1",
      url: "https://vortibd.com/media/icon/2018_10_21_12_23_25_logo.gif",
      collegeName: "Dhaka Cantonment Girls' Public School & College",
      appStatus: "Applied for Eight",
      appDate: "Created Nov 01,2022",
      paymentStatus: "Paid",
      appUrl: "assets/images/avatars/brian-hughes.jpg",
      appName: "Asifur Rahman",
      applicationId: "Application ID 220112",
      status: "Download",
      peek: "Hide",
    },
    {
      id: "2",
      url: "https://vortibd.com/media/icon/2022_11_15_11_45_26_2021_11_14_12_24_53_spsc.jpg",
      collegeName: "Shaheed Police Smrity College",
      appStatus: "Apply for Nine",
      appDate: "Created Nov 01,2022",
      paymentStatus: "Unpaid",
      appUrl: "assets/images/avatars/female-01.jpg",
      appName: "Dorin Islam",
      applicationId: "Application ID 220162",
      status: "Pay Now",
      peek: "Hide",
    },
    {
      id: "3",
      url: "https://vortibd.com/media/icon/2018_11_07_05_15_02_logo_header.png",
      collegeName: "Ispahani Public School & College",
      appStatus: "Applied for Eight",
      appDate: "Created Nov 01,2022",
      paymentStatus: "Draft",
      appUrl: "assets/images/avatars/female-04.jpg",
      appName: "Pial Paul",
      applicationId: "Application ID 223412",
      status: "Apply Now",
      peek: "Hide",
    },
  ];

  displayedColumns: string[] = ["ProgramName", "VersionName", "ShiftName", "SessionName", "FormAmount", "ConvAmount", "Action",];
  institueName: string;

  collegeOptions: boolean = false;
  isResetButtonDisabled: boolean = true;
  isNextButtonDisabled: boolean = true;
  isSchoolNextButtonDisabled: boolean = true;
  isInstituteVisibleOne: boolean = false;
  isInstituteVisibleTwo: boolean = true;
  isListPage: boolean = false;
  isProfileVisible = false;
  firstNextButton: boolean = true;
  showStepper: boolean = false;
  schoolNextButton = false;
  schoolResettButton = false;
  schoolResetButtonTwo = false;
  applicantBanner = false;
  imageSrc = "./assets/images/placeholderImage.png";

  versionControl = new FormControl();
  circularControl = new FormControl();
  categoryControl = new FormControl();
  sessionControl = new FormControl();
  shiftControl = new FormControl();
  institutionControl = new FormControl("");
  admissionClassControl = new FormControl({ value: "", disabled: true });
  groupControl = new FormControl({ value: "", disabled: true });
  schoolGroupControl = new FormControl({ value: "", disabled: true });
  sscRollControl = new FormControl({ value: "", disabled: true });
  boardControl = new FormControl({ value: "", disabled: true });
  sscPassingYearControl = new FormControl({ value: "", disabled: true });
  profileControl = new FormControl({ value: "", disabled: false });
  searchControl = new FormControl({ value: "", disabled: true });

  public data: any[] = this.appData;
  public delayedData: any[] = [];
  selectedStudent: any;
  Selected_AutoSearchProfile: any;
  schoolStudents: any;
  circularFields: any;

  schools = Dummy_Pair;
  programs = Dummy_Pair;
  versions = null;
  categories = null;
  sessions = null;
  shifts = null;
  groups = null;
  boards = null;
  sscYears = null;
  circulars = null;
  Main_InstituteData = null;
  Main_OpenProgramData = null;
  Main_OpenCircularData = null;
  studentName = null;
  studentImage = null;
  fetchingData = true;
  foundError = false;
  ProgramType = "";

  constructor(
    private _router: Router,
    private _dashboardService: DashboardService,
    private matSnackBar: MatSnackBar
  ) {
    this.getInstituteData();
  }

  ngOnInit() {
    setTimeout(() => {
      this.applicantBanner = true;
      this.delayedData = this.data;
    }, 2000);

    this.sscRollControl.valueChanges.subscribe((val) => {
      if (val.length === 6) {
        this.boardControl.enable();
        this.groupControl.disable();
      } else if (val.length >= 1) {
        this.boardControl.disable();
        this.groupControl.disable();
      } else {
        this.boardControl.disable();
        this.groupControl.enable();
      }
    });

    this.searchControl = new FormControl('', [Validators.pattern('^[a-zA-Z .]*$')]);

    this.searchControl.valueChanges
      .pipe(
        distinctUntilChanged()
      )
      .subscribe((value) => {
        if (value.length >= 2 && /^[a-zA-Z]+$/.test(value)) {
          this._dashboardService.AutoCompleteStudent({ q: value }).subscribe((data) => {
            this.schoolStudents = data.data;
          });
          this.boardControl.disable();
          this.schoolGroupControl.disable();
          this.isSchoolNextButtonDisabled = false;
          this.admissionClassControl.disable();
          this.categoryControl.disable();
        } else if (value.length < 2 || /\d/.test(value)) {
          this.schoolStudents = [];
          this.Selected_AutoSearchProfile = null;
          this.isSchoolNextButtonDisabled = true;
        } else {
          this.isSchoolNextButtonDisabled = false;
        }
      });
  }

  showAll() {
    this.delayedData = this.appData;
  }

  showPaid() {
    this.delayedData = this.appData.filter(item => item.paymentStatus === 'Paid');
  }

  showUnpaid() {
    this.delayedData = this.appData.filter(item => item.paymentStatus === 'Unpaid');
  }

  showDraft() {
    this.delayedData = this.appData.filter(item => item.paymentStatus === 'Draft');
  }

  hideItem(item: any) {
    this.delayedData = this.delayedData.filter(x => x !== item);
  }

  hideAll() {
    this.delayedData = [];
  }

  getInstituteData(): void {
    let ibody = "0";
    this._dashboardService.GetInstituteData(ibody).subscribe(
      (data: any) => {
        // console.log(data, "getInstituteData");
        this.Main_InstituteData = data.data;
        if (this.Main_InstituteData != null) {
          this.schools = this.Main_InstituteData.VortiBDClients;
        }
        this.fetchingData = false;
      },
      (error: any) => {
        this.foundError = true;
        this.fetchingData = false;
        console.log(error, "error");
      }
    );
  }

  getOpenProgramsData(ibody): void {
    this._dashboardService.GetOpenProgramsData(ibody).subscribe(
      (data: any) => {
        // console.log(data, "getOpenProgramsData");

        this.Main_OpenProgramData = data.data;

        if (this.Main_OpenProgramData != null) {
          this.programs = this.Main_OpenProgramData.AddmissionOpenPrograms;
        }

        this.fetchingData = false;
      },
      (error: any) => {
        this.foundError = true;
        this.fetchingData = false;
        console.log(error, "error");
      }
    );
  }

  getOpenProgramsDetails(ibody): void {
    this._dashboardService.GetOpenProgramsDetails(ibody).subscribe(
      (data: any) => {
        // console.log(data, "getOpenProgramsDetails");
        this.Main_OpenProgramData = data.data;
        if (this.Main_OpenProgramData != null) {
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramVersions)) {
            this.versions = this.Main_OpenProgramData.OpenProgramVersions;
            if (this.versions.length == 1) {
              this.versionControl.setValue(this.versions[0].value);
            }
            // console.log(this.versions, "versions");
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenCirculars)) {
            this.circulars = this.Main_OpenProgramData.OpenCirculars;
            if (this.circulars.length == 1) {
              this.circularControl.setValue(this.circulars[0].value);
            }
            // console.log(this.circulars, "circulars");
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramCategories)) {
            this.categories = this.Main_OpenProgramData.OpenProgramCategories;
            if (this.categories.length == 1) {
              this.categoryControl.setValue(this.categories[0].value);
            }
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramSessions)) {
            this.sessions = this.Main_OpenProgramData.OpenProgramSessions;
            if (this.sessions.length == 1) {
              this.sessionControl.setValue(this.sessions[0].value);
            }
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramShifts)) {
            this.shifts = this.Main_OpenProgramData.OpenProgramShifts;
            if (this.shifts.length == 1) {
              this.shiftControl.setValue(this.shifts[0].value);
            }
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramGroups)) {
            this.groups = this.Main_OpenProgramData.OpenProgramGroups;
            if (this.groups.length == 1) {
              this.groupControl.setValue(this.groups[0].value);
            }
          }
          if (!isEmpty(this.Main_OpenProgramData.OpenProgramBoards)) {
            this.boards = this.Main_OpenProgramData.OpenProgramBoards;
            if (this.boards.length == 1) {
              this.boardControl.setValue(this.boards[0].value);
            }
          }
          if (!isEmpty(this.Main_OpenProgramData.SSCPassingYear)) {
            this.sscYears = this.Main_OpenProgramData.SSCPassingYear;
            let preselected = this.sscYears.filter(
              (year) => year.selected == true
            );
            this.sscPassingYearControl.setValue(preselected[0].value);
          }
          if (!isEmpty(this.Main_OpenProgramData.AddmissionOpenProgramDetails)) {
            this.ProgramType =
              this.Main_OpenProgramData.AddmissionOpenProgramDetails.ProgramType.toUpperCase();
          }
        }
        this.fetchingData = false;
        // console.log( this.Main_OpenProgramData.AddmissionOpenProgramDetails.ProgramId, "programId" );
      },
      (error: any) => {
        this.foundError = true;
        this.fetchingData = false;
        console.log(error, "error");
      }
    );
  }

  Select_AutoProfile(value): void {
    this.Selected_AutoSearchProfile = value;
    // console.log(this.Selected_AutoSearchProfile, 'Selected_AutoSearchProfile');
  }

  getOpenCirculars(ibody): void {
    this._dashboardService.GetOpenCirculars(ibody).subscribe(
      (data: any) => {
        this.Main_OpenCircularData = data.data;

        if (this.Main_OpenCircularData != null) {
          this.circulars = this.Main_OpenCircularData.OpenCirculars;
          const uniqueRowsMap = new Map<string, any>();
          this.circulars.forEach(row => {
            const uniqueId = `${row.ProgramName}-${row.VersionName}-${row.ShiftName}-${row.SessionName}-${row.FormAmount}-${row.ConvAmount}`;
            if (!uniqueRowsMap.has(uniqueId)) {
              uniqueRowsMap.set(uniqueId, row);
            }
          });
          this.circularFields = Array.from(uniqueRowsMap.values());
        }
        this.fetchingData = false;
      },
      (error: any) => {
        this.foundError = true;
        this.fetchingData = false;
        console.log(error, "error");
      }
    );
  }

  instituteChange(event): void {
    const result = this.schools.filter((ins) => ins.value == event.source.value);
    this.institueName = result[0].name.split("~")[0];
    this.imageSrc = `https://cloudcampus24-cdn.s3.ap-southeast-1.amazonaws.com/cdn/img/client/logo/${Utils.getInstituteName(result[0].name)}.png`;
    this.ClearControlsForInstitute();
    this.getOpenProgramsData(event.source.value);
    this.admissionClassControl.enable();
    this.groupControl.disable();
    this.schoolGroupControl.disable();
    this.sscRollControl.disable();
    this.boardControl.disable();
    this.sscPassingYearControl.disable();
    this.profileControl.disable();
    this.isResetButtonDisabled = false;
  }

  admissionClassChange(event) {
    // console.log(event.source.value, event.source.selected);
    let body = `${this.institutionControl.value}/${event.source.value}`;
    this.ClearControlsForClass();
    this.getOpenProgramsDetails(body);
    this.getOpenCirculars(body);
    this.institutionControl.disable();
    this.schoolGroupControl.disable();
    this.sscRollControl.disable();
    this.boardControl.disable();
    this.sscPassingYearControl.disable();
    this.groupControl.enable();
    this.searchControl.enable();
    this.firstNextButton = false;
    this.Main_OpenProgramData = null;
    this.schoolResetButtonTwo = false;
    this.schoolResettButton = true;
    // console.log(this.institutionControl.value, "ins");
    // console.log(this.institutionControl, "ins");
    // console.log(event.source.value, "class");
  }

  versionChange(event): void {
    // console.log(event.source.value, event.source.selected);
  }

  categoryChange(event): void {
    this.schoolGroupControl.disable();
    this.admissionClassControl.disable();
    this.isProfileVisible = true;
    this.schoolNextButton = true;
    // console.log(event.source.value, event.source.selected);
  }

  sessionChange(event): void {
    // console.log(event.source.value, event.source.selected);
  }

  shiftChange(event): void {
    // console.log(event.source.value, event.source.selected);
  }

  groupChange(event): void {
    this.institutionControl.disable();
    this.admissionClassControl.disable();
    this.boardControl.disable();
    this.sscPassingYearControl.disable();
    this.sscRollControl.enable();
    // console.log(event.source.value, event.source.selected);
  }

  sscRollChange(event): void {
    // console.log(event.target.value);
  }

  boardChange(event): void {
    this.institutionControl.disable();
    this.admissionClassControl.disable();
    this.groupControl.disable();
    this.sscRollControl.disable();
    this.sscPassingYearControl.enable();
    this.sscPassingYearControl.patchValue('--');
    // console.log(event.source.value, event.source.selected);
  }

  sscPassingYearChange(event): void {
    this.boardControl.disable();
    this.isNextButtonDisabled = false;
    // console.log(event.source.value, event.source.selected);
  }

  showList() {
    this.sscPassingYearControl.disable();
    this.profileControl.disable();
    this.searchControl.disable();
    this.isListPage = true;
    this.schoolNextButton = false;
    this.schoolResetButtonTwo = true;
    this.schoolResettButton = false;
    this.isNextButtonDisabled = true;
    // console.log(this.searchControl.value, "searchControl");
  }

  goToForm(circular) {
    // console.log(circular, "circular");
    // console.log(circular.ShiftId, "circular");

    let FormParam: FormParam_Interface = {};
    if (this.ProgramType == "C") {
      if (this.sscRollControl.value == "") {
        this.sscRollControl.markAsTouched();
        this.matSnackBar.open("Please Enter SSC Roll", "Close", {
          verticalPosition: "top",
          duration: 2000,
        });
        return;
      }
      if (!isEmpty(this.boards) && this.boardControl.value == "") {
        this.boardControl.markAsTouched();
        this.matSnackBar.open("Please Select A Board", "Close", {
          verticalPosition: "top",
          duration: 2000,
        });
        return;
      }
      if (!isEmpty(this.sscYears) && this.sscPassingYearControl.value == "") {
        this.sscPassingYearControl.markAsTouched();
        this.matSnackBar.open("Please Select SSC Passing Year", "Close", {
          verticalPosition: "top",
          duration: 2000,
        });
        return;
      }
      FormParam = {
        AddmissionOpenProgramDetails: this.Main_OpenProgramData.AddmissionOpenProgramDetails,
        selectedInstituteId: this.institutionControl.value,
        selectedInstituteText: this.schools != null ? this.schools.filter((ins) => ins.value == this.institutionControl.value)[0].name : "",
        SelectedVersion: this.versionControl.value,
        SelectedVersionText: this.versions != null ? this.versions.filter((ver) => ver.value == this.versionControl.value)[0].name : "",
        SelectedShift: this.shiftControl.value,
        SelectedShiftText: this.shifts != null ? this.shifts.filter((sft) => sft.value == this.shiftControl.value)[0].name : "",
        SelectedBoard: this.boardControl.value,
        SelectedBoardText: this.boards != null ? this.boards.filter((brd) => brd.value == this.boardControl.value)[0].name : "",
        SelectedSession: this.sessionControl.value,
        SelectedSessionText: this.sessions != null ? this.sessions.filter((ses) => ses.value == this.sessionControl.value)[0].name : "",
        SelectedCategory: this.categoryControl.value,
        SelectedCategoryText: this.categories != null ? this.categories.filter((cat) => cat.value == this.categoryControl.value)[0].name : "",
        SelectedCategoryType: this.categories != null ? this.categories.filter((cat) => cat.value == this.categoryControl.value)[0].isDefense.toUpperCase() : "",
        SelectedGroup: this.groupControl.value,
        SelectedGroupText: this.groups != null ? this.groups.filter((grp) => grp.value == this.groupControl.value)[0].name : "",
        SelectedSSCYear: this.sscPassingYearControl.value,
        SelectedSSCYearText: this.sscYears != null ? this.sscYears.filter((yr) => yr.value == this.sscPassingYearControl.value)[0].name : "",
        SelectedSSCRoll: this.sscRollControl.value,
        SelectedProgramId: circular.ProgramId,
        SelectedProgramName: circular.ProgramName,
        SelectedProgramType: circular.ProgramType,
        SelectedVersionName: circular.VersionName,
        SelectedShiftName: circular.ShiftName,
        SelectedSessionName: circular.SessionName,
        SelectedVersionId: circular.VersionId,
        SelectedShiftId: circular.ShiftId,
        SelectedSessionId: circular.SessionId,
        SelectedFormAmount: circular.FormAmount,
        SelectedConvAmount: circular.ConvAmount,
        AutoCompleteName: this.searchControl.value,
        AutoCompleteImage: this.Selected_AutoSearchProfile != null ? this.Selected_AutoSearchProfile.CandidateImage : "",
      };
    }

    if (this.ProgramType == "S") {
      if (!isEmpty(this.categories) && this.categoryControl.value == "") {
        this.categoryControl.markAsTouched();
        this.matSnackBar.open("Please Select A Category", "Close", {
          verticalPosition: "top",
          duration: 2000,
        });
        return;
      }
      // console.log(circular.ShiftId, "circular.shiftID");
      FormParam = {
        AddmissionOpenProgramDetails: this.Main_OpenProgramData.AddmissionOpenProgramDetails, selectedInstituteId: this.institutionControl.value, selectedInstituteText: this.schools != null ? this.schools.filter((ins) => ins.value == this.institutionControl.value)[0].name : "",
        SelectedCategory: this.categoryControl.value,
        SelectedCategoryText: this.categories != null ? this.categories.filter((cat) => cat.value == this.categoryControl.value)[0].name : "",
        SelectedCategoryType: this.categories != null ? this.categories.filter((cat) => cat.value == this.categoryControl.value)[0].isDefense.toUpperCase() : "",
        SelectedGroup: this.groupControl.value,
        SelectedGroupText: this.groups != null ? this.groups.filter((grp) => grp.value == this.groupControl.value)[0].name : "",
        AutoCompleteName: this.searchControl.value,
        AutoCompleteImage: this.Selected_AutoSearchProfile != null ? this.Selected_AutoSearchProfile.CandidateImage : "",
        SelectedProgramId: circular.ProgramId,
        SelectedProgramName: circular.ProgramName,
        SelectedProgramType: circular.ProgramType,
        SelectedVersionName: circular.VersionName,
        SelectedShiftName: circular.ShiftName,
        SelectedSessionName: circular.SessionName,
        SelectedVersionId: circular.VersionId,
        SelectedShiftId: circular.ShiftId,
        SelectedSessionId: circular.SessionId,
        SelectedFormAmount: circular.FormAmount,
        SelectedConvAmount: circular.ConvAmount,
      };
      // console.log(circular.ShiftId);
    }
    localStorage.removeItem(ConstantNames.FormParam);
    this._dashboardService.FormParam = JSON.stringify(FormParam);
    this._router.navigateByUrl("/dashboard/Apply");
    // console.log(this.circulars);
    // console.log(FormParam.SelectedShiftId, "SelectedShiftId");
    // console.log(FormParam.SelectedSSCRoll, "FormParam"); 
  }

  ClearControlsForInstitute(): void {
    this.admissionClassControl.setValue("");
    this.versionControl.setValue("");
    this.circularControl.setValue("");
    this.categoryControl.setValue("");
    this.sessionControl.setValue("");
    this.shiftControl.setValue("");
    this.groupControl.setValue("");
    this.sscRollControl.setValue("");
    this.boardControl.setValue("");
    this.sscPassingYearControl.setValue("");
    this.profileControl.setValue("");
    this.emptyDropDowns();
  }

  ClearControlsForClass(): void {
    this.versionControl.setValue("");
    this.circularControl.setValue("");
    this.categoryControl.setValue("");
    this.sessionControl.setValue("");
    this.shiftControl.setValue("");
    this.groupControl.setValue("");
    this.sscRollControl.setValue("");
    this.boardControl.setValue("");
    this.sscPassingYearControl.setValue("");
    this.profileControl.setValue("");
    this.emptyDropDowns();
  }

  ClearAllControls(): void {
    this.institutionControl.setValue("");
    this.admissionClassControl.setValue("");
    this.versionControl.setValue("");
    this.circularControl.setValue("");
    this.categoryControl.setValue("");
    this.sessionControl.setValue("");
    this.shiftControl.setValue("");
    this.groupControl.setValue("");
    this.schoolGroupControl.setValue("");
    this.sscRollControl.setValue("");
    this.boardControl.setValue("");
    this.sscPassingYearControl.setValue("");
    this.profileControl.setValue("");
    this.searchControl.setValue("");
  }

  emptyDropDowns(): void {
    this.versions = null;
    this.circulars = null;
    this.categories = null;
    this.sessions = null;
    this.shifts = null;
    this.groups = null;
    this.boards = null;
    this.ProgramType = "";
  }

  formReset(): void {
    this.ClearAllControls();
    this.admissionClassControl.disable();
    this.profileControl.enable();
    this.institutionControl.enable();
    this.categoryControl.enable();
    this.emptyDropDowns();
    this.imageSrc = "./assets/images/placeholderImage.png";
    this.isResetButtonDisabled = true;
    this.isInstituteVisibleOne = true;
    this.firstNextButton = true;
    this.schoolNextButton = false;
    this.isInstituteVisibleTwo = false;
    this.collegeOptions = false;
    this.isProfileVisible = false;
    this.isListPage = false;
    this.schoolResetButtonTwo = false;
    this.schoolResettButton = false;
    this.isNextButtonDisabled = true;
    this.Selected_AutoSearchProfile = null;
    localStorage.removeItem("InsType");
  }

  onCloseStepper(eventData: any) {
    // console.log(eventData, "onCloseStepper");
    this.showStepper = eventData.close;
    this.formReset();
    window.scroll({ top: 0, left: 0, behavior: "smooth", });
  }

}