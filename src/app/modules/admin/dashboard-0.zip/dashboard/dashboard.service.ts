import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Service } from 'app/services/service';
import UrlConfig from 'app/Urlconfig/urlConfig';
import ConstantNames from 'app/Urlconfig/constantNames';


@Injectable()
export class DashboardService
{
  constructor(private service: Service) { }


  GetUiConfigs(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.UI_CONFIGS + model);
  }

  GetDropdownCotrols(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.DROPDOWN_CONTROLS + model);
  }

  GetInstituteData(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.INSTITUTE_DATA + model);
  }

  GetOpenProgramsData(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.OPEN_PROGRAM_DATA + model);
  }

  GetOpenProgramsDetails(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.OPEN_PROGRAM_DETAILS + model);
    // return this.service.get(UrlConfig.OPEN_PROGRAM_DETAILS + model.ins + '/' + model.class);
  }

  GetProfileSubjects(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.PROFILE_SUBJECTS + model);
  }

  GetOpenCirculars(model: any): Observable<any>
  {
    return this.service.get(UrlConfig.OPEN_CIRCULARS + model);
  }

  SaveStudentForm(model: any, id: any): Observable<any>
  {
    return this.service.post(UrlConfig.STUDENT_SAVE(id), model);
  }
  
  SaveGuardianForm(model: any): Observable<any>
  {
    return this.service.post(UrlConfig.GUARDIAN_SAVE, model);
  }

  SaveAddressForm(model: any): Observable<any>
  {
    return this.service.post(UrlConfig.ADDRESS_SAVE, model);
  }

  SavePreviousAcademicInfoCollegeForm(model: any): Observable<any>
  {
    return this.service.post(UrlConfig.PREVIOUSCOLLEGE_SAVE, model);
  }
  
  SavePreviousAcademicInfoSchoolForm(model: any): Observable<any>
  {
    return this.service.post(UrlConfig.PREVIOUSSCHOOL_SAVE, model);
  }

  AutoCompleteStudent(model: any): Observable<any>
  {
    return this.service.post(UrlConfig.AUTOCOMPLETE, model);
  }
  
  SaveCourseCurriculumCollegeForm(model: any, id: any): Observable<any> {
    return this.service.post(UrlConfig.COURSECURRICULUM_COLLEGE(id), model);
  }


  set FormParam(data: any)
  {
    localStorage.setItem(ConstantNames.FormParam, data);
  }

  get FormParam(): any
  {
    return localStorage.getItem(ConstantNames.FormParam) ?? null
  }



}

