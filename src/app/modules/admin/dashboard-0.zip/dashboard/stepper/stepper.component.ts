/** @format */

import { BreakpointObserver } from "@angular/cdk/layout";
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { Component, EventEmitter, Input, Output, ViewChild, ViewEncapsulation } from "@angular/core";
import { FormGroup, UntypedFormBuilder, UntypedFormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { MatStepper, MatStepperIntl, StepperOrientation } from "@angular/material/stepper";
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { BaseControl } from "app/models/dynamic-form";
import Utils from "app/Utility/utils";
import { forkJoin, map, Observable, Subscription } from "rxjs";
import { DashboardService } from "../dashboard.service";

@Component({
  selector: "stepper-apply",
  templateUrl: "./stepper.component.html",
  styleUrls: ["./stepper.component.scss"],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { showError: true },
    },
  ],
  encapsulation: ViewEncapsulation.None,
})

export class StepperApplyComponent
{
  @Input() controls1: BaseControl<string>[] = [];
  @Input() controls2: BaseControl<string>[] = [];
  @Input() QuotaInvalid: boolean;
  @Input() GenderInvalid: boolean;

  @Output() closeStepper = new EventEmitter<{ close: boolean }>();

  @ViewChild("horizontalStepper") stepper: MatStepper;

  stepperOrientation: Observable<StepperOrientation>;

  form1: FormGroup;
  form2: FormGroup;

  errorMessage: string = null;
  studentSaveData = null;
  addressInfo = null;
  guardianInfo = null;
  courseCurriculumForCollege = null;
  previousAcademicInfoCollege = null;
  previousAcademicInfoforSchool = null;
  studentFormInfo = null;
  MainDropdownData = null;
  CurriculumSubjectsList = null;
  studentInfoShow = true;
  guardianInfoShow = true;
  addressInfoShow = true;
  defenceInfoShow = true;
  academicInfoforCollegeShow = true;
  academicInfoforSchoolShow = true;
  courseCurriculumCollegeShow = true;
  fetchingData = true;
  submitted = false;
  foundError = false;
  banner = false;

  maxDate = new Date();

  candidateImage = [];

  selectedStudent: any;
  schoolStudents: any;
  FormParam: any;
  studentImage: any;
  StudentProfileImage: any;
  FatherProfileImage: any;
  MotherProfileImage: any;
  LocalGuardianProfileImage: any;
  DefenceProfileImage: any;

  imageUrl: string;
  dummySting = "none"

  schoolStudentsSubscription: Subscription;
  horizontalStepperForm: UntypedFormGroup;
  horizontalStepperForm1: UntypedFormGroup;

  dummyB64: any;
  dummyName: any;

  // feetInches(value: number): string {
  //   const feet = Math.floor(value);
  //   const inches = Math.round((value - feet) * 12);
  //   return `${feet}'${inches}"`;
  // }

  // formatHeight(value: number): string {
  //   return this.feetInches(value);
  // }

  /**
   * Constructor
   */
  constructor(
    private _formBuilder: UntypedFormBuilder,
    private _matStepperIntl: MatStepperIntl,
    private _breakpointObserver: BreakpointObserver,
    private _router: Router,
    private _dashboardService: DashboardService,
    private matSnackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
  )
  {
    this._matStepperIntl.optionalLabel = "";

    let InsType = localStorage.getItem("InsType");

    this.FormParam = JSON.parse(this._dashboardService.FormParam);

    if (this.FormParam.AddmissionOpenProgramDetails.ProgramType == "S")
    {
      this.academicInfoforCollegeShow = false;
      this.courseCurriculumCollegeShow = false;
      this.academicInfoforSchoolShow = true;
    } else
    {
      this.academicInfoforCollegeShow = true;
      this.courseCurriculumCollegeShow = true;
      this.academicInfoforSchoolShow = false;
    }

    this.stepperOrientation = _breakpointObserver
      .observe("(min-width: 800px)")
      .pipe(map(({ matches }) => (matches ? "horizontal" : "vertical")));

    this.getPageData();

    if (this.FormParam && this.FormParam.AutoCompleteImage !== '')
    {
      this.imageUrl = this.FormParam.AutoCompleteImage;
      this.toDataURL(this.sanitizer.bypassSecurityTrustUrl(this.FormParam.AutoCompleteImage), (base64image) =>
      {

        let fdf = this.FormParam.AutoCompleteImage.replace('\\', '').replace('\\', '').replace('\\', '');
        let dd = {
          'userBase64File': (<string>base64image).split(',')[1],
          'userFilename': fdf.split("/")[this.FormParam.AutoCompleteImage.split("/").length - 1]
        }
        this.StudentProfileImage = dd;

      });
    }
    else
    {
      this.imageUrl = "none"
    }
    // console.log(this.FormParam.AutoCompleteImage, ' this.FormParam.AutoCompleteImage');
    // console.log(this.FormParam.SelectedShiftId, "SelectedShiftId");

  }

  // check() {
  //   console.log(this.StudentProfileImage, ' this.StudentProfileImage');
  // }

  getPageData(): void
  {
    let uibody = `${this.FormParam.selectedInstituteId}/${this.FormParam.AddmissionOpenProgramDetails.ProgramType}`;
    let ddbody = this.FormParam.selectedInstituteId;
    let csbody = `${this.FormParam.selectedInstituteId}/${this.FormParam.SelectedGroup}`;

    let _apiRequests = [
      this._dashboardService.GetUiConfigs(uibody),
      this._dashboardService.GetDropdownCotrols(ddbody),
    ];

    if (this.FormParam.AddmissionOpenProgramDetails.ProgramType == "C")
    {
      _apiRequests.push(this._dashboardService.GetProfileSubjects(csbody));
    }

    forkJoin(_apiRequests).subscribe(
      (data: any) =>
      {
        // console.log(data, "getPageData");

        let mainData = data[0].data;

        this.MainDropdownData = data[1].data;
        this.banner = true;

        if (data.length == 3)
        {
          this.CurriculumSubjectsList = data[2].data;
        }
        let Student_Information = mainData.find((x) => x.FormGroupId === "Student_Information");
        this.studentFormInfo = Student_Information.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});

        let Guardian_Information = mainData.find((x) => x.FormGroupId === "Guardian_Information");
        this.guardianInfo = Guardian_Information.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});

        let Address_Information = mainData.find((x) => x.FormGroupId === "Address_Information");
        this.addressInfo = Address_Information.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});

        let Previous_Academic_Information_Collage = mainData.find((x) => x.FormGroupId === "Previous_Academic_Information_Collage");
        this.previousAcademicInfoCollege = Previous_Academic_Information_Collage.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});

        let Previous_Academic_Information_School = mainData.find((x) => x.FormGroupId === "Previous_Academic_Information_School");
        this.previousAcademicInfoforSchool = Previous_Academic_Information_School.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});
        let Course_Curriculum_College = mainData.find((x) => x.FormGroupId === "Course_Curriculum_College");

        this.courseCurriculumForCollege = Course_Curriculum_College.UIConfigItems.reduce((o, key) => ({ ...o, [key.KeyName]: key }), {});

        // console.log(this.studentFormInfo, 'this.studentFormInfo');

        this.horizontalStepperForm = this._formBuilder.group({
          studentInformation: this._formBuilder.group({
            studentFullNameEng: ["", this.studentFormInfo.studentFullNameEng.Required ? Validators.required : null,],
            studentFullNameBng: ["", this.studentFormInfo.studentFullNameBng.Required ? Validators.required : null,],
            studentBloodGroup: ["", this.studentFormInfo.studentBloodGroup.Required ? Validators.required : null,],
            studentContactNo: ["", this.studentFormInfo.studentContactNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentNationality: ["", this.studentFormInfo.studentNationality.Required ? Validators.required : null,],
            studentHomeDistrict: ["", this.studentFormInfo.studentHomeDistrict.Required ? Validators.required : null,],
            studentDateOfbirth: ["", this.studentFormInfo.studentDateOfbirth.Required ? Validators.required : null,],
            studentBirthRegistrationNo: ["", this.studentFormInfo.studentBirthRegistrationNo.Required ? [Validators.required, Validators.pattern(/^\d{17}$/)] : null],
            studentReligion: ["", this.studentFormInfo.studentReligion.Required ? Validators.required : null,],
            studentEmargencyContactNo: ["", this.studentFormInfo.studentEmargencyContactNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentGender: ["", this.studentFormInfo.studentGender.Required ? Validators.required : null,],
            studentEmail: ["", this.studentFormInfo.studentEmail.Required ? [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/)] : null,],
            studentHeight: ["", this.studentFormInfo.studentHeight.Required ? Validators.required : null,],
            studentWeight: ["", this.studentFormInfo.studentWeight.Required ? Validators.required : null,],
            studentFreedomFighterQuota: ["", this.studentFormInfo.studentFreedomFighterQuota.Required ? Validators.required : null,],
            studentIsAutism: ["", this.studentFormInfo.studentIsAutism.Required ? Validators.required : null,],
            studentOwnHouse: ["", this.studentFormInfo.studentOwnHouse.Required ? Validators.required : null,],
            studentHouseIncome: ["", this.studentFormInfo.studentHouseIncome.Required ? Validators.required : null,],
            studentHouseExpense: ["", this.studentFormInfo.studentHouseExpense.Required ? Validators.required : null,],
          }),

          guardianInformation: this._formBuilder.group({
            studentFathersNameEng: ["", this.guardianInfo.studentFathersNameEng.Required ? Validators.required : null,],
            studentFathersNameBng: ["", this.guardianInfo.studentFathersNameBng.Required ? Validators.required : null,],
            studentFathersTIN: ["", this.guardianInfo.studentFathersTIN.Required ? [Validators.required, Validators.pattern(/^[0-9]{12}$/)] : null,],
            studentFathersContactNumber: ["", this.guardianInfo.studentFathersContactNumber.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentFathersEducation: ["", this.guardianInfo.studentFathersEducation.Required ? Validators.required : null,],
            studentFathersNationalID: ["", this.guardianInfo.studentFathersNationalID.Required ? [Validators.required, Validators.pattern(/^[0-9]{10,13}$/)] : null,],
            studentFathersOccupation: ["", this.guardianInfo.studentFathersOccupation.Required ? Validators.required : null,],
            studentFathersOfficeName: ["", this.guardianInfo.studentFathersOfficeName.Required ? Validators.required : null,],
            studentFathersDesignation: ["", this.guardianInfo.studentFathersDesignation.Required ? Validators.required : null,],
            studentFathersOfficeAddress: ["", this.guardianInfo.studentFathersOfficeAddress.Required ? Validators.required : null,],
            studentFathersOfficePhoneNo: ["", this.guardianInfo.studentFathersOfficePhoneNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentFathersAnnualIncome: ["", this.guardianInfo.studentFathersAnnualIncome.Required ? Validators.required : null,],
            studentFathersEmail: ["", this.guardianInfo.studentFathersEmail.Required ? [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/)] : null,],

            studentMothersNameEng: ["", this.guardianInfo.studentMothersNameEng.Required ? Validators.required : null,],
            studentMothersNameBng: ["", this.guardianInfo.studentMothersNameBng.Required ? Validators.required : null,],
            studentMothersTIN: ["", this.guardianInfo.studentMothersTIN.Required ? Validators.required : null,],
            studentMothersContactNumber: ["", this.guardianInfo.studentMothersContactNumber.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentMothersEducation: ["", this.guardianInfo.studentMothersEducation.Required ? Validators.required : null,],
            studentMothersNationalID: ["", this.guardianInfo.studentMothersNationalID.Required ? [Validators.required, Validators.pattern(/^[0-9]{10,13}$/)] : null,],
            studentMothersOccupation: ["", this.guardianInfo.studentMothersOccupation.Required ? Validators.required : null,],
            studentMothersOfficeName: ["", this.guardianInfo.studentMothersOfficeName.Required ? Validators.required : null,],
            studentMothersDesignation: ["", this.guardianInfo.studentMothersDesignation.Required ? Validators.required : null,],
            studentMothersOfficeAddress: ["", this.guardianInfo.studentMothersOfficeAddress.Required ? Validators.required : null,],
            studentMothersOfficePhoneNo: ["", this.guardianInfo.studentMothersOfficePhoneNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentMothersAnnualIncome: ["", this.guardianInfo.studentMothersAnnualIncome.Required ? Validators.required : null,],
            studentMothersEmail: ["", this.guardianInfo.studentMothersEmail.Required ? [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/)] : null,],

            studentLocalGuardiansType: ["", this.guardianInfo.studentLocalGuardiansType.Required ? Validators.required : null,],
            studentLocalGuardiansRelation: ["", this.guardianInfo.studentLocalGuardiansRelation.Required ? Validators.required : null,],
            studentLocalGuardiansNameEng: ["", this.guardianInfo.studentLocalGuardiansNameEng.Required ? Validators.required : null,],
            studentLocalGuardiansNameBng: ["", this.guardianInfo.studentLocalGuardiansNameBng.Required ? Validators.required : null,],
            studentLocalGuardiansTIN: ["", this.guardianInfo.studentLocalGuardiansTIN.Required ? Validators.required : null,],
            studentLocalGuardiansContactNo: ["", this.guardianInfo.studentLocalGuardiansContactNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentLocalGuardiansEducation: ["", this.guardianInfo.studentLocalGuardiansEducation.Required ? Validators.required : null,],
            studentLocalGuardiansNationalID: ["", this.guardianInfo.studentLocalGuardiansNationalID.Required ? [Validators.required, Validators.pattern(/^[0-9]{10,13}$/)] : null,],
            studentLocalGuardiansOccupation: ["", this.guardianInfo.studentLocalGuardiansOccupation.Required ? Validators.required : null,],
            studentLocalGuardiansOfficeName: ["", this.guardianInfo.studentLocalGuardiansOfficeName.Required ? Validators.required : null,],
            studentLocalGuardiansDesignation: ["", this.guardianInfo.studentLocalGuardiansDesignation.Required ? Validators.required : null,],
            studentLocalGuardiansOfficeAddress: ["", this.guardianInfo.studentLocalGuardiansOfficeAddress.Required ? Validators.required : null,],
            studentLocalGuardiansOfficePhoneNo: ["", this.guardianInfo.studentLocalGuardiansOfficePhoneNo.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
            studentLocalGuardiansAnnualIncome: ["", this.guardianInfo.studentLocalGuardiansAnnualIncome.Required ? Validators.required : null,],
            studentLocalGuardiansEmail: ["", this.guardianInfo.studentLocalGuardiansEmail.Required ? [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/)] : null,],

            studentDefencePerson: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefencePerson.Required ? Validators.required : null,],
            studentDefenceJobLocationOrCantonmentName: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceJobLocationOrCantonmentName.Required ? Validators.required : null,],
            studentDefenceRegimentNo: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceRegimentNo.Required ? Validators.required : null,],
            studentDefenceRank: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceRank.Required ? Validators.required : null,],
            studentDefenceStationNameOrBattalion: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceStationNameOrBattalion.Required ? Validators.required : null,],
            studentDefenceServiceStatus: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceServiceStatus.Required ? Validators.required : null,],
            studentDefenceService: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceService.Required ? Validators.required : null,],
            studentDefenceRetirement: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceRetirement.Required ? Validators.required : null,],
            studentDefenceNoofChild: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceNoofChild.Required ? Validators.required : null,],
            studentDefenceMissionStart: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceMissionStart.Required ? Validators.required : null,],
            studentDefenceMissionEnd: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceMissionEnd.Required ? Validators.required : null,],
            studentDefenceMissionPlace: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceMissionPlace.Required ? Validators.required : null,],
            studentDefenceUnitName: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceUnitName.Required ? Validators.required : null,],
            studentDefenceBANumber: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceBANumber.Required ? Validators.required : null,],
            studentDefenceCourse: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceCourse.Required ? Validators.required : null,],
            studentDefenceCrops: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceCrops.Required ? Validators.required : null,],
            studentDefenceCOorOCsName: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceCOorOCsName.Required ? Validators.required : null,],
            studentDefenceCOorOCsContact: ["", this.FormParam.SelectedCategoryType != "N" && this.guardianInfo.studentDefenceCOorOCsContact.Required ? [Validators.required, Validators.pattern(/^\0?1[3456789][0-9]{8}$/)] : null,],
          }),

          addressInformation: this._formBuilder.group({
            presentAreaAddress: ["", this.addressInfo.presentAreaAddress.Required ? Validators.required : null,],
            presentPostCode: ["", this.addressInfo.presentPostCode.Required ? Validators.required : null,],
            presentDistrict: ["", this.addressInfo.presentDistrict.Required ? Validators.required : null,],
            presentDivision: ["", this.addressInfo.presentDivision.Required ? Validators.required : null,],
            presentPostOffice: ["", this.addressInfo.presentPostOffice.Required ? Validators.required : null,],
            presentVillage: ["", this.addressInfo.presentVillage.Required ? Validators.required : null,],
            presentPoliceStation: ["", this.addressInfo.presentPoliceStation.Required ? Validators.required : null,],
            presentAddressEng: ["", this.addressInfo.presentAddressEng.Required ? Validators.required : null,],
            presentAddressBng: ["", this.addressInfo.presentAddressBng.Required ? Validators.required : null,],
            presentHouse: ["", this.addressInfo.presentHouse.Required ? Validators.required : null,],
            presentSection: ["", this.addressInfo.presentSection.Required ? Validators.required : null,],
            presentPlot: ["", this.addressInfo.presentPlot.Required ? Validators.required : null,],
            presentSector: ["", this.addressInfo.presentSector.Required ? Validators.required : null,],
            presentUpazila: ["", this.addressInfo.presentUpazila.Required ? Validators.required : null,],
            presentRoad: ["", this.addressInfo.presentRoad.Required ? Validators.required : null,],
            presentUnion: ["", this.addressInfo.presentUnion.Required ? Validators.required : null,],
            presentBlock: ["", this.addressInfo.presentBlock.Required ? Validators.required : null,],
            presentWardNo: ["", this.addressInfo.presentWardNo.Required ? Validators.required : null,],
            presentPaurashava: ["", this.addressInfo.presentPaurashava.Required ? Validators.required : null,],

            permanentSameAs: ["", this.addressInfo.permanentSameAs.Required ? Validators.required : null,],
            permanentAreaAddress: ["", this.addressInfo.permanentAreaAddress.Required ? Validators.required : null,],
            permanentPostCode: ["", this.addressInfo.permanentPostCode.Required ? Validators.required : null,],
            permanentDistrict: ["", this.addressInfo.permanentDistrict.Required ? Validators.required : null,],
            permanentDivision: ["", this.addressInfo.permanentDivision.Required ? Validators.required : null,],
            permanentPostOffice: ["", this.addressInfo.permanentPostOffice.Required ? Validators.required : null,],
            permanentVillage: ["", this.addressInfo.permanentVillage.Required ? Validators.required : null,],
            permanentPoliceStation: ["", this.addressInfo.permanentPoliceStation.Required ? Validators.required : null,],
            permanentAddressEng: ["", this.addressInfo.permanentAddressEng.Required ? Validators.required : null,],
            permanentAddressBng: ["", this.addressInfo.permanentAddressBng.Required ? Validators.required : null,],
            permanentHouse: ["", this.addressInfo.permanentHouse.Required ? Validators.required : null,],
            permanentSection: ["", this.addressInfo.permanentSection.Required ? Validators.required : null,],
            permanentPlot: ["", this.addressInfo.permanentPlot.Required ? Validators.required : null,],
            permanentSector: ["", this.addressInfo.permanentSector.Required ? Validators.required : null,],
            permanentUpazila: ["", this.addressInfo.permanentUpazila.Required ? Validators.required : null,],
            permanentRoad: ["", this.addressInfo.permanentRoad.Required ? Validators.required : null,],
            permanentUnion: ["", this.addressInfo.permanentUnion.Required ? Validators.required : null,],
            permanentBlock: ["", this.addressInfo.permanentBlock.Required ? Validators.required : null,],
            permanentWardNo: ["", this.addressInfo.permanentWardNo.Required ? Validators.required : null,],
            permanentPaurashava: ["", this.addressInfo.permanentPaurashava.Required ? Validators.required : null,],

            localGuardianSameAs: ["", this.addressInfo.localGuardianSameAs.Required ? Validators.required : null,],
            localGuardianAreaAddress: ["", this.addressInfo.localGuardianAreaAddress.Required ? Validators.required : null,],
            localGuardianPostCode: ["", this.addressInfo.localGuardianPostCode.Required ? Validators.required : null,],
            localGuardianDistrict: ["", this.addressInfo.localGuardianDistrict.Required ? Validators.required : null,],
            localGuardianDivision: ["", this.addressInfo.localGuardianDivision.Required ? Validators.required : null,],
            localGuardianPostOffice: ["", this.addressInfo.localGuardianPostOffice.Required ? Validators.required : null,],
            localGuardianVillage: ["", this.addressInfo.localGuardianVillage.Required ? Validators.required : null,],
            localGuardianPoliceStation: ["", this.addressInfo.localGuardianPoliceStation.Required ? Validators.required : null,],
            localGuardianAddressEng: ["", this.addressInfo.localGuardianAddressEng.Required ? Validators.required : null,],
            localGuardianAddressBng: ["", this.addressInfo.localGuardianAddressBng.Required ? Validators.required : null,],
            localGuardianHouse: ["", this.addressInfo.localGuardianHouse.Required ? Validators.required : null,],
            localGuardianSection: ["", this.addressInfo.localGuardianSection.Required ? Validators.required : null,],
            localGuardianPlot: ["", this.addressInfo.localGuardianPlot.Required ? Validators.required : null,],
            localGuardianSector: ["", this.addressInfo.localGuardianSector.Required ? Validators.required : null,],
            localGuardianUpazila: ["", this.addressInfo.localGuardianUpazila.Required ? Validators.required : null,],
            localGuardianRoad: ["", this.addressInfo.localGuardianRoad.Required ? Validators.required : null,],
            localGuardianUnion: ["", this.addressInfo.localGuardianUnion.Required ? Validators.required : null,],
            localGuardianBlock: ["", this.addressInfo.localGuardianBlock.Required ? Validators.required : null,],
            localGuardianWardNo: ["", this.addressInfo.localGuardianWardNo.Required ? Validators.required : null,],
            localGuardianPaurashava: ["", this.addressInfo.localGuardianPaurashava.Required ? Validators.required : null,],
          }),

          previousAcademicInformationforCollege: this._formBuilder.group({
            previousAcademicInfoCollegeGroup: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeGroup.Required ? Validators.required : null,],
            previousAcademicInfoCollegeRollNo: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeRollNo.Required ? Validators.required : null,],
            previousAcademicInfoCollegeBoard: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeBoard.Required ? Validators.required : null,],
            previousAcademicInfoCollegeRegNo: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeRegNo.Required ? Validators.required : null,],
            previousAcademicInfoCollegeExamination: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeExamination.Required ? Validators.required : null,],
            previousAcademicInfoCollegeSubject: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeSubject.Required ? Validators.required : null,],
            previousAcademicInfoCollegeDistrict: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeDistrict.Required ? Validators.required : null,],
            previousAcademicInfoCollegeFromSession: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeFromSession.Required ? Validators.required : null,],
            previousAcademicInfoCollegeToSession: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeToSession.Required ? Validators.required : null,],
            previousAcademicInfoCollegeCourseDuration: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeCourseDuration.Required ? Validators.required : null,],
            previousAcademicInfoCollegeTotalCredit: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeTotalCredit.Required ? Validators.required : null,],
            previousAcademicInfoCollegeCentreCode: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeCentreCode.Required ? Validators.required : null,],
            previousAcademicInfoCollegeObtainedOutofno: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeObtainedOutofno.Required ? Validators.required : null,],
            previousAcademicInfoCollegeObtainedWithout4thsubject: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeObtainedWithout4thsubject.Required ? Validators.required : null,],
            previousAcademicInfoCollegeObtainedWith4thsubject: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeObtainedWith4thsubject.Required ? Validators.required : null,],
            previousAcademicInfoCollegeObtainedResult: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeObtainedResult.Required ? Validators.required : null,],
            previousAcademicInfoCollegePassingYear: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegePassingYear.Required ? Validators.required : null,],
            previousAcademicInfoCollegeInstitute: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeInstitute.Required ? Validators.required : null,],
            previousAcademicInfoCollegeExamHeldIn: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeExamHeldIn.Required ? Validators.required : null,],
            previousAcademicInfoCollegeGPA: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeGPA.Required ? Validators.required : null,], previousAcademicInfoCollegeGPAwithout4thsubject: ["", this.previousAcademicInfoCollege.previousAcademicInfoCollegeGPAwithout4thsubject.Required ? Validators.required : null,],
          }),

          previousAcademicInformationforSchool: this._formBuilder.group({
            previousAcademicInfoSchoolLastSchoolName: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolLastSchoolName.Required ? Validators.required : null,],
            previousAcademicInfoSchoolLastExamName: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolLastExamName.Required ? Validators.required : null,],
            previousAcademicInfoSchoolLastResult: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolLastResult.Required ? Validators.required : null,],
            previousAcademicInfoSchoolSection: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolSection.Required ? Validators.required : null,],
            previousAcademicInfoSchoolRoll: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolRoll.Required ? Validators.required : null,],
            previousAcademicInfoSchoolInstituteAddress: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolInstituteAddress.Required ? Validators.required : null,],
            previousAcademicInfoSchoolTCInfo: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolTCInfo.Required ? Validators.required : null,],
            previousAcademicInfoSchoolTCNo: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolTCNo.Required ? Validators.required : null,],
            previousAcademicInfoSchoolTCDate: ["", this.previousAcademicInfoforSchool.previousAcademicInfoSchoolTCDate.Required ? Validators.required : null,],
          }),

          courseCurriculumCollege: this._formBuilder.group({
            courseCurriculumCollege3rdSubjectForHSC: ["", this.courseCurriculumForCollege.courseCurriculumCollege3rdSubjectForHSC.Required ? Validators.required : null,],
            courseCurriculumCollege4thSubjectForHSC: ["", this.courseCurriculumForCollege.courseCurriculumCollege4thSubjectForHSC.Required ? Validators.required : null,],
          }),
        });
        this.fetchingData = false;
        this.foundError = false;

        if (this.FormParam.AutoCompleteName)
        {
          this.horizontalStepperForm.controls.studentInformation.patchValue({
            studentFullNameEng: this.FormParam.AutoCompleteName,
          });
          this.submitted = true;
        }
      },
      (error: any) =>
      {
        this.foundError = true;
        this.fetchingData = false;
        console.log(error, "error");
      }
    );
  }

  Rem_C(): void
  {
    // console.log(this.horizontalStepperForm.controls.guardianInformation, "guardianInformation before");

    this.horizontalStepperForm.removeControl("previousAcademicInformationforSchool");
    // (this.horizontalStepperForm.get('guardianInformation') as FormGroup).removeControl('studentDefenceBANumber');
    // console.log(this.horizontalStepperForm.controls, "guardianInformation after");

    // console.log(this.horizontalStepperForm.controls.guardianInformation, 'guardianInformation after');
  }

  public findInvalidControls()
  {
    const invalid = [];
    const controls = (this.horizontalStepperForm.get("guardianInformation") as FormGroup).controls;
    for (const name in controls)
    {
      if (controls[name].invalid)
      {
        invalid.push(name);
      }
    }
    return console.log(invalid);
  }

  checkValid()
  {
    // (this.horizontalStepperForm.get('guardianInformation') as FormGroup).
    document.getElementsByClassName("ng-invalid");
  }

  permanentAddRadioButton(): void
  {
    let info = this.horizontalStepperForm.controls.addressInformation.getRawValue();
    // console.log(info.presentAreaAddress, "presentAreaAddress");
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentAreaAddress: info.presentAreaAddress, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentPostCode: info.presentPostCode, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentDistrict: info.presentDistrict, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentDivision: info.presentDivision, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentPostOffice: info.presentPostOffice, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentVillage: info.presentVillage, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentPoliceStation: info.presentPoliceStation, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentAddressEng: info.presentAddressEng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentAddressBng: info.presentAddressBng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentHouse: info.presentHouse, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentSection: info.presentSection, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentPlot: info.presentPlot, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentSector: info.presentSector, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentUpazila: info.presentUpazila, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentRoad: info.presentRoad, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentUnion: info.presentUnion, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentBlock: info.presentBlock, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentWardNo: info.presentWardNo, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ permanentPaurashava: info.presentPaurashava, });

    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAreaAddress.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostCode.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDistrict.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDivision.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostOffice.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentVillage.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPoliceStation.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressEng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressBng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentHouse.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSection.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPlot.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSector.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUpazila.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentRoad.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUnion.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentBlock.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentWardNo.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPaurashava.disable();
  }

  resetPermanentAddRadioButton(): void
  {
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAreaAddress.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostCode.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDistrict.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDivision.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostOffice.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentVillage.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPoliceStation.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressEng.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressBng.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentHouse.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSection.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPlot.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSector.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUpazila.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentRoad.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUnion.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentBlock.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentWardNo.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPaurashava.setValue("");

    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAreaAddress.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostCode.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDistrict.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentDivision.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPostOffice.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentVillage.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPoliceStation.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressEng.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentAddressBng.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentHouse.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSection.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPlot.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentSector.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUpazila.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentRoad.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentUnion.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentBlock.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentWardNo.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].permanentPaurashava.enable();
  }

  localAddRadioButton(): void
  {
    let info = this.horizontalStepperForm.controls.addressInformation.getRawValue();
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAreaAddress: info.presentAreaAddress, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPostCode: info.presentPostCode, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianDistrict: info.presentDistrict, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianDivision: info.presentDivision, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPostOffice: info.presentPostOffice, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianVillage: info.presentVillage, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPoliceStation: info.presentPoliceStation, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAddressEng: info.presentAddressEng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAddressBng: info.presentAddressBng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianHouse: info.presentHouse, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianSection: info.presentSection, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPlot: info.presentPlot, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianSector: info.presentSector, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianUpazila: info.presentUpazila, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianRoad: info.presentRoad, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianUnion: info.presentUnion, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianBlock: info.presentBlock, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianWardNo: info.presentWardNo, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPaurashava: info.presentPaurashava, });

    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAreaAddress.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostCode.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDistrict.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDivision.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostOffice.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianVillage.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPoliceStation.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressEng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressBng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianHouse.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSection.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPlot.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSector.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUpazila.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianRoad.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUnion.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianBlock.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianWardNo.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPaurashava.disable();
  }

  localAddPermanentRadioButton(): void
  {
    let info = this.horizontalStepperForm.controls.addressInformation.getRawValue();
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAreaAddress: info.permanentAreaAddress, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPostCode: info.permanentPostCode, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianDistrict: info.permanentDistrict, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianDivision: info.permanentDivision, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPostOffice: info.permanentPostOffice, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianVillage: info.permanentVillage, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPoliceStation: info.permanentPoliceStation, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAddressEng: info.permanentAddressEng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianAddressBng: info.permanentAddressBng, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianHouse: info.permanentHouse, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianSection: info.permanentSection, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPlot: info.permanentPlot, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianSector: info.permanentSector, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianUpazila: info.permanentUpazila, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianRoad: info.permanentRoad, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianUnion: info.permanentUnion, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianBlock: info.permanentBlock, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianWardNo: info.permanentWardNo, });
    this.horizontalStepperForm.controls.addressInformation.patchValue({ localGuardianPaurashava: info.permanentPaurashava, });

    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAreaAddress.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostCode.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDistrict.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDivision.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostOffice.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianVillage.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPoliceStation.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressEng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressBng.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianHouse.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSection.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPlot.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSector.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUpazila.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianRoad.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUnion.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianBlock.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianWardNo.disable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPaurashava.disable();
  }

  resetLocalAddRadioButton(): void
  {
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAreaAddress.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostCode.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDistrict.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDivision.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostOffice.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianVillage.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPoliceStation.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressEng.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressBng.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianHouse.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSection.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPlot.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSector.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUpazila.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianRoad.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUnion.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianBlock.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianWardNo.setValue("");
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPaurashava.setValue("");

    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAreaAddress.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostCode.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDistrict.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianDivision.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPostOffice.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianVillage.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPoliceStation.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressEng.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianAddressBng.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianHouse.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSection.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPlot.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianSector.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUpazila.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianRoad.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianUnion.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianBlock.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianWardNo.enable();
    this.horizontalStepperForm.controls.addressInformation["controls"].localGuardianPaurashava.enable();
  }

  Save_studentInformation()
  {

    if (this.studentFormInfo.studentPhoto.Required && this.StudentProfileImage == null)
    {
      this.matSnackBar.open("Profile photo is required", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }

    let si_form = this.horizontalStepperForm.controls.studentInformation.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "ProfileNo": "",
      "studentID": "",
      "studentIDC": "",
      "sourceID": 1,
      "programID": this.FormParam.AddmissionOpenProgramDetails.ProgramId ? this.FormParam.AddmissionOpenProgramDetails.ProgramId : "",
      "subjectID": 1,//eft
      "groupID": this.FormParam.SelectedGroup ? this.FormParam.SelectedGroup : "2",//eft
      "classID": 1,//eft
      "sectionID": 2,//eft
      "shiftID": this.FormParam.SelectedShiftId ? this.FormParam.SelectedShiftId : "",
      "sessionID": this.FormParam.SelectedSessionId ? this.FormParam.SelectedSessionId : "",
      "versionID": this.FormParam.SelectedVersionId ? this.FormParam.SelectedVersionId : "",
      "studentCatID": this.FormParam.SelectedCategory ? this.FormParam.SelectedCategory : "",
      "studentRoll": this.FormParam.SelectedSSCRoll ? this.FormParam.SelectedSSCRoll : "",
      "studentName": tI_obj.StudentName ? tI_obj.StudentName : "",
      "fatherName": tI_obj.FatherName ? tI_obj.FatherName : "",
      "motherName": tI_obj.MotherName ? tI_obj.MotherName : "",
      "presentAddr": "",
      "contactNo": tI_obj.ContactNo ? tI_obj.ContactNo : "",
      "isRegular": "",
      "isActive": "",
      "isPromotion": "",
      "brdVrstyID": this.FormParam.SelectedBoard ? this.FormParam.SelectedBoard : "1",//eft
      "adminType": "N",//eft
      "admissionStatus": "",
      "studentIDType": "",
      "isArchive": "",
      "idCardNoS": "",
      "houseID": 1,// eft
      "idCardNoG": tI_obj.NationalIDG ? tI_obj.NationalIDG : "",
      "idCardNoF": tI_obj.NationalIDF ? tI_obj.NationalIDF : "",
      "idCardNoM": tI_obj.NationalIDM ? tI_obj.NationalIDM : "",
      "studentNameBangla": tI_obj.StudentNameBangla ? tI_obj.StudentNameBangla : "",
      "fatherNameBangla": tI_obj.FatherNameBangla ? tI_obj.FatherNameBangla : "",
      "motherNameBangla": tI_obj.MotherNameBangla ? tI_obj.MotherNameBangla : "",
      "trackingID": "",
      "isSendSMS": "",
      "flagStudentInfoSaved": true,
      "createUserIPAddress": "",
      "updateUserIPAddress": "",
      "bloodGroup": tI_obj.BloodGroup ? tI_obj.BloodGroup : "",
      "nationalID": "",
      "homeDisID": tI_obj.HomeDisID ? tI_obj.HomeDisID : "",
      "birthDate": tI_obj.BirthDate ? tI_obj.BirthDate : "",
      "birthID": tI_obj.BirthID ? tI_obj.BirthID : "",
      "religionID": tI_obj.ReligionID ? tI_obj.ReligionID : "",
      "emargencyContactNo": "",
      "studentSex": tI_obj.StudentSex ? tI_obj.StudentSex : "",
      "emailAddress": tI_obj.EmailAddress ? tI_obj.EmailAddress : "",
      "studentHeight": tI_obj.StudentHeight ? tI_obj.StudentHeight : "",
      "studentWeight": tI_obj.StudentWeight ? tI_obj.StudentWeight : "",
      "ownHouse": tI_obj.OwnHouse ? tI_obj.OwnHouse : "",
      "houseIncome": tI_obj.HouseIncome ? tI_obj.HouseIncome : "",
      "houseExpense": tI_obj.HouseExpense ? tI_obj.HouseExpense : "",
      "freedomFighter": tI_obj.FreedomFighter ? tI_obj.FreedomFighter : "",
      "isAutism": tI_obj.IsAutism ? tI_obj.IsAutism : "",
      "photoPathS": "",
      "studentSign": "",
      "PhotoSName": this.StudentProfileImage != null ? this.StudentProfileImage.userFilename : "",
      "PhotoSBase64": this.StudentProfileImage != null ? this.StudentProfileImage.userBase64File : "",
      "SignSName": "",
      "SignSBase64": "",

    };
    // console.log(this.StudentProfileImage.userFilename, "this.StudentProfileImage.userFilename");
    // console.log(this.StudentProfileImage.userBase64File, "this.StudentProfileImage.userBase64File");

    this._dashboardService.SaveStudentForm(body, this.FormParam.AddmissionOpenProgramDetails.ProgramId).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.studentSaveData = data.data;
        this.matSnackBar.open("Student Information Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });
  }

  Save_guardianInformation()
  {

    if (this.guardianInfo.studentFathersPhoto.Required && this.FatherProfileImage == null)
    {
      this.matSnackBar.open("Father Profile photo is required", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }

    if (this.guardianInfo.studentMothersPhoto.Required && this.MotherProfileImage == null)
    {
      this.matSnackBar.open("Mother Profile photo is required", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }

    if (this.guardianInfo.studentLocalGuardiansPhoto.Required && this.LocalGuardianProfileImage == null)
    {
      this.matSnackBar.open("Local Guardian Profile photo is required", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }

    if (this.studentSaveData == null)
    {
      this.matSnackBar.open("Please save student information First", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }

    let si_form = this.horizontalStepperForm.controls.guardianInformation.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "studentMasterId": this.studentSaveData.Id,
      "studentID": this.studentSaveData.StudentID,
      "fatherName": tI_obj.FatherName ? tI_obj.FatherName : "",
      "fatherNameBangla": tI_obj.FatherNameBangla ? tI_obj.FatherNameBangla : "",
      "contactNoF": tI_obj.ContactNoF ? tI_obj.ContactNoF : "",
      "emailF": "",
      "fatherOfficeName": tI_obj.FatherOfficeName ? tI_obj.FatherOfficeName : "",
      "fatherOfficeAddr": tI_obj.FatherOfficeAddr ? tI_obj.FatherOfficeAddr : "",
      "fatherOcpID": null,
      "fatherOfficeDesig": tI_obj.FatherOfficeDesig ? tI_obj.FatherOfficeDesig : "",
      "fatherOfficePhone": tI_obj.FatherOfficePhone ? tI_obj.FatherOfficePhone : "",
      "fatherTIN": tI_obj.FatherTIN ? tI_obj.FatherTIN : "",
      "nationalIDF": tI_obj.NationalIDF ? tI_obj.NationalIDF : "",
      "annualIncomeF": tI_obj.AnnualIncomeF ? tI_obj.AnnualIncomeF : "",
      "photoPathF": "",
      "photoUrlF": "",
      "fatherEducation": tI_obj.FatherEducation ? tI_obj.FatherEducation : "",
      "fatherSign": "",
      "employeeNoF": "",
      "departmentF": "",
      "motherName": tI_obj.MotherName ? tI_obj.MotherName : "",
      "motherNameBangla": tI_obj.MotherNameBangla ? tI_obj.MotherNameBangla : "",
      "emailAddress": tI_obj.EmailAddress ? tI_obj.EmailAddress : "",
      "contactNoM": tI_obj.ContactNoM ? tI_obj.ContactNoM : "",
      "emailM": "",
      "motherOfficeName": tI_obj.MotherOfficeName ? tI_obj.MotherOfficeName : "",
      "motherOfficeAddr": tI_obj.MotherOfficeAddr ? tI_obj.MotherOfficeAddr : "",
      "motherOcpID": null,
      "motherOfficeDesig": tI_obj.MotherOfficeDesig ? tI_obj.MotherOfficeDesig : "",
      "motherOfficePhone": tI_obj.MotherOfficePhone ? tI_obj.MotherOfficePhone : "",
      "motherTIN": tI_obj.MotherTIN ? tI_obj.MotherTIN : "",
      "nationalIDM": tI_obj.NationalIDM ? tI_obj.NationalIDM : "",
      "annualIncomeM": "", //same as father
      "photoPathM": "",
      "photoUrlM": "",
      "motherSign": "",
      "motherEducation": tI_obj.MotherEducation ? tI_obj.MotherEducation : "",
      "employeeNoM": "",
      "departmentM": "",
      "guardianName": tI_obj.GuardianName ? tI_obj.GuardianName : "",
      "guardianR": "",
      "contactNoG": tI_obj.ContactNoG ? tI_obj.ContactNoG : "",
      "emailG": "",
      "guardOfficeName": tI_obj.GuardOfficeName ? tI_obj.GuardOfficeName : "",
      "guardOfficeAddr": tI_obj.GuardOfficeAddr ? tI_obj.GuardOfficeAddr : "",
      "guardianOcpID": null,
      "guardOfficeDesig": tI_obj.GuardOfficeDesig ? tI_obj.GuardOfficeDesig : "",
      "guardOfficePhone": tI_obj.GuardOfficePhone ? tI_obj.GuardOfficePhone : "",
      "guardTIN": tI_obj.GuardTIN ? tI_obj.GuardTIN : "",
      "nationalIDG": tI_obj.NationalIDG ? tI_obj.NationalIDG : "",
      "annualIncomeG": tI_obj.AnnualIncomeG ? tI_obj.AnnualIncomeG : "",
      "photoPathG": "",
      "armyNo": "",
      "regimentNo": "",
      "defencePerson": "",
      "fatherRankID": null,
      "unitID": null,
      "childNo": tI_obj.ChildNo ? tI_obj.ChildNo : "",
      "stationName": tI_obj.StationName ? tI_obj.StationName : "",
      "isRetired": tI_obj.IsRetired ? tI_obj.IsRetired : "",
      "retireDate": tI_obj.RetireDate ? tI_obj.RetireDate : "",
      "districtID": null,
      "missionStartDate": tI_obj.MissionStartDate ? tI_obj.MissionStartDate : "",
      "missionEndDate": tI_obj.MissionEndDate ? tI_obj.MissionEndDate : "",
      "unitName": tI_obj.UnitName ? tI_obj.UnitName : "",
      "placeOfMission": tI_obj.PlaceOfMission ? tI_obj.PlaceOfMission : "",
      "photoUrlG": "",
      "guardinSign": "",
      "guardianEducation": tI_obj.GuardianEducation ? tI_obj.GuardianEducation : "",
      "baBssSnkIdNo": tI_obj.BaBssSnkIdNo ? tI_obj.BaBssSnkIdNo : "",
      "gurdianNameBangla": tI_obj.GurdianNameBangla ? tI_obj.GurdianNameBangla : "",
      "employeeNoG": "",
      "departmentG": "",
      "ambitionID": "",
      "activeStatus": true,
      "createUserIPAddress": "",
      "updateUserIPAddress": "",
      "createUserID": 0,
      "createTime": new Date().toISOString(),
      "updateTime": "2022-12-21T12:02:18.557Z",
      "updateUserID": 0,
      "SignFBase64": "",
      "SignFName": "",
      "SignMBase64": "",
      "SignMName": "",
      "SignGBase64": "",
      "SignGName": "",
      "PhotoFName": this.FatherProfileImage != null ? this.FatherProfileImage.userFilename : "",
      "PhotoFBase64 ": this.FatherProfileImage != null ? this.FatherProfileImage.userBase64File : "",
      "PhotoMName": this.MotherProfileImage != null ? this.MotherProfileImage.userFilename : "",
      "PhotoMBase64 ": this.MotherProfileImage != null ? this.MotherProfileImage.userBase64File : "",
      "PhotoGName": this.LocalGuardianProfileImage != null ? this.LocalGuardianProfileImage.userFilename : "",
      "PhotoGBase64": this.LocalGuardianProfileImage != null ? this.LocalGuardianProfileImage.userBase64File : "",
    }
    // console.log(body, "gbody");
    // console.log(body.createTime, "gbodytime");


    this._dashboardService.SaveGuardianForm(body).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.matSnackBar.open("Guardian Information Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });

  }

  Save_addressInformation()
  {
    if (this.studentSaveData == null)
    {
      this.matSnackBar.open("Please save student information First", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }
    let si_form = this.horizontalStepperForm.controls.addressInformation.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "studentMasterId": this.studentSaveData.Id,
      "studentID": this.studentSaveData.StudentID,
      "houseSRA": tI_obj.HouseSRA ? tI_obj.HouseSRA : "",
      "plotSRA": tI_obj.PlotSRA ? tI_obj.PlotSRA : "",
      "roadSRA": tI_obj.RoadSRA ? tI_obj.RoadSRA : "",
      "blockSRA": tI_obj.BlockSRA ? tI_obj.BlockSRA : "",
      "sectionSRA": tI_obj.SectionSRA ? tI_obj.SectionSRA : "",
      "sectorSRA": tI_obj.SectorSRA ? tI_obj.SectorSRA : "",
      "areaSRA": tI_obj.AreaSRA ? tI_obj.AreaSRA : "",
      "wardSRA": "",
      "wardNoSRA": tI_obj.WardNoSRA ? tI_obj.WardNoSRA : "",
      "districtIDSRA": tI_obj.DistrictIDSRA ? tI_obj.DistrictIDSRA : "",
      "divisionIDSRA": tI_obj.DivisionIDSRA ? tI_obj.DivisionIDSRA : "",
      "upazilaIDSRA": tI_obj.UpazilaIDSRA ? tI_obj.UpazilaIDSRA : "",
      "unionIDSRA": tI_obj.UnionIDSRA ? tI_obj.UnionIDSRA : "",
      "paurashavaIDSRA": tI_obj.PaurashavaIDSRA ? tI_obj.PaurashavaIDSRA : "",
      "postOfficeIDSRA": tI_obj.PostOfficeIDSRA ? tI_obj.PostOfficeIDSRA : "",
      "postCodeSRA": tI_obj.PostCodeSRA ? tI_obj.PostCodeSRA : "",
      "policeStationIDSRA": tI_obj.PoliceStationIDSRA ? tI_obj.PoliceStationIDSRA : "",
      "villageSRA": tI_obj.VillageSRA ? tI_obj.VillageSRA : "",
      "addressSRA": tI_obj.AddressSRA ? tI_obj.AddressSRA : "",
      "houseLGA": tI_obj.HouseLGA ? tI_obj.HouseLGA : "",
      "plotLGA": tI_obj.PlotLGA ? tI_obj.PlotLGA : "",
      "roadLGA": tI_obj.RoadLGA ? tI_obj.RoadLGA : "",
      "blockLGA": tI_obj.BlockLGA ? tI_obj.BlockLGA : "",
      "sectionLGA": tI_obj.SectionLGA ? tI_obj.SectionLGA : "",
      "sectorLGA": tI_obj.SectorLGA ? tI_obj.SectorLGA : "",
      "areaLGA": tI_obj.AreaLGA ? tI_obj.AreaLGA : "",
      "wardLGA": "",
      "wardNoLGA": tI_obj.WardNoLGA ? tI_obj.WardNoLGA : "",
      "districtIDLGA": tI_obj.DistrictIDLGA ? tI_obj.DistrictIDLGA : "",
      "divisionIDLGA": tI_obj.DivisionIDLGA ? tI_obj.DivisionIDLGA : "",
      "upazilaIDLGA": tI_obj.UpazilaIDLGA ? tI_obj.UpazilaIDLGA : "",
      "unionIDLGA": tI_obj.UnionIDLGA ? tI_obj.UnionIDLGA : "",
      "paurashavaIDLGA": tI_obj.PaurashavaIDLGA ? tI_obj.PaurashavaIDLGA : "",
      "postOfficeIDLGA": tI_obj.PostOfficeIDLGA ? tI_obj.PostOfficeIDLGA : "",
      "postCodeLGA": tI_obj.PostCodeLGA ? tI_obj.PostCodeLGA : "",
      "policeStationIDLGA": tI_obj.PoliceStationIDLGA ? tI_obj.PoliceStationIDLGA : "",
      "villageLGA": tI_obj.VillageLGA ? tI_obj.VillageLGA : "",
      "addressLGA": tI_obj.AddressLGA ? tI_obj.AddressLGA : "",
      "housePA": tI_obj.HousePA ? tI_obj.HousePA : "",
      "plotPA": tI_obj.PlotPA ? tI_obj.PlotPA : "",
      "roadPA": tI_obj.RoadPA ? tI_obj.RoadPA : "",
      "blockPA": tI_obj.BlockPA ? tI_obj.BlockPA : "",
      "sectionPA": tI_obj.SectionPA ? tI_obj.SectionPA : "",
      "sectorPA": tI_obj.SectorPA ? tI_obj.SectorPA : "",
      "areaPA": tI_obj.AreaPA ? tI_obj.AreaPA : "",
      "wardPA": "",
      "wardNoPA": tI_obj.WardNoPA ? tI_obj.WardNoPA : "",
      "districtIDPA": tI_obj.DistrictIDPA ? tI_obj.DistrictIDPA : "",
      "divisionIDPA": tI_obj.DivisionIDPA ? tI_obj.DivisionIDPA : "",
      "upazilaIDPA": tI_obj.UpazilaIDPA ? tI_obj.UpazilaIDPA : "",
      "unionIDPA": tI_obj.UnionIDPA ? tI_obj.UnionIDPA : "",
      "paurashavaIDPA": tI_obj.PaurashavaIDPA ? tI_obj.PaurashavaIDPA : "",
      "postOfficeIDPA": tI_obj.PostOfficeIDPA ? tI_obj.PostOfficeIDPA : "",
      "postCodePA": tI_obj.PostCodePA ? tI_obj.PostCodePA : "",
      "policeStationIDPA": tI_obj.PoliceStationIDPA ? tI_obj.PoliceStationIDPA : "",
      "villagePA": tI_obj.VillagePA ? tI_obj.VillagePA : "",
      "addressPA": tI_obj.AddressPA ? tI_obj.AddressPA : "",
      "activeStatus": true,
      "createUserID": 0,
      "createTime": new Date().toISOString(),
      "createUserIPAddress": "",
      "updateUserID": 0,
      "updateTime": "2022-12-21T12:03:28.127Z",
      "updateUserIPAddress": "",
      "addressSRABangla": "",
      "addressPABangla": ""
    }

    // console.log(body, "adbody");

    this._dashboardService.SaveAddressForm(body).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.matSnackBar.open("Address Information Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });

  }

  Save_previousAcademicInformationforCollege()
  {
    if (this.studentSaveData == null)
    {
      this.matSnackBar.open("Please save student information First", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }
    let si_form = this.horizontalStepperForm.controls.previousAcademicInformationforCollege.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "studentMasterId": this.studentSaveData.Id,
      "studentID": this.studentSaveData.StudentID,
      "srlNo": 0,
      "examID": 2,
      "subjectID": 0,
      "groupID": 0,
      "boardID": tI_obj.BoardID ? tI_obj.BoardID : "",
      "areaID": 1,
      "centreCode": tI_obj.CentreCode ? tI_obj.CentreCode : "",
      "educationIns": tI_obj.EducationIns ? tI_obj.EducationIns : "",
      "totalMarks": "",
      "without4th": tI_obj.Without4th ? tI_obj.Without4th : "",
      "with4th": tI_obj.With4th ? tI_obj.With4th : "",
      "result": tI_obj.Result ? tI_obj.Result : "",
      "resultOn": "G",
      "passYear": tI_obj.PassYear ? tI_obj.PassYear : "",
      "session1": tI_obj.Session1 ? tI_obj.Session1 : "",
      "session2": tI_obj.Session2 ? tI_obj.Session2 : "",
      "rgdNo": tI_obj.RgdNo ? tI_obj.RgdNo : "",
      "rollNo": tI_obj.RollNo ? tI_obj.RollNo : "",
      "duration": tI_obj.Duration ? tI_obj.Duration : "",
      "totalCredit": tI_obj.TotalCredit ? tI_obj.TotalCredit : "",
      "examHeld": tI_obj.ExamHeld ? tI_obj.ExamHeld : "",
      "casualRoll": "",
      "issueNo": "",
      "isRegular": "Y",
      "issueDate": "2022-12-21T12:05:22.119Z",
      "issueType": "N",
      "sourceID": 1,
      "totalMarksWithTenSub": 0,
      "totalMarksWithoutSub": 0,
      "activeStatus": true,
      "createUserID": 0,
      "createTime": new Date().toISOString(),
      "createUserIPAddress": "",
      "updateUserID": 0,
      "updateTime": "2022-12-21T12:05:22.119Z",
      "updateUserIPAddress": ""
    }
    // console.log(body, "pacbody");
    this._dashboardService.SavePreviousAcademicInfoCollegeForm(body).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.matSnackBar.open("Previous Academic Information Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });

  }

  Save_previousAcademicInformationforSchool()
  {
    if (this.studentSaveData == null)
    {
      this.matSnackBar.open("Please save student information First", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }
    let si_form = this.horizontalStepperForm.controls.previousAcademicInformationforSchool.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "studentMasterId": this.studentSaveData.Id,
      "studentID": this.studentSaveData.StudentID,
      "lastInstitute": tI_obj.LastInstitute ? tI_obj.LastInstitute : "",
      "tcInfo": tI_obj.TCInfo ? tI_obj.TCInfo : "",
      "lastExam": tI_obj.LastExam ? tI_obj.LastExam : "",
      "lastSchoolAdd": tI_obj.LastSchoolAdd ? tI_obj.LastSchoolAdd : "",
      "lastProgram": "",
      "lastSection": tI_obj.LastSection ? tI_obj.LastSection : "",
      "lastRoll": tI_obj.LastRoll ? tI_obj.LastRoll : "",
      "lastTcNo": tI_obj.LastTcNo ? tI_obj.LastTcNo : "",
      "lastTcDate": tI_obj.LastTcDate ? tI_obj.LastTcDate : "",
    }
    // console.log(body, "pasbody");

    this._dashboardService.SavePreviousAcademicInfoSchoolForm(body).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.matSnackBar.open("Previous Academic Information Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });

  }

  Save_courseCurriculumCollege()
  {
    if (this.studentSaveData == null)
    {
      this.matSnackBar.open("Please save student information First", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      return;
    }
    let si_form = this.horizontalStepperForm.controls.courseCurriculumCollege.getRawValue();
    // console.log(si_form, "si_form");

    let tI_obj = Utils.altObj(si_form);

    // console.log(tI_obj, "tI_obj");

    let body = {
      "clientId": this.FormParam.selectedInstituteId ? this.FormParam.selectedInstituteId : "",
      "studentId": this.studentSaveData.Id,
      "thirdSubject": "29",
      "fourthSubject": "9",
      "compulsorySubject": "",
      "compulsorySubject1": "",
      "compulsorySubject2": "",
      "compulsorySubject3": "",
      "compulsorySubjectList": [
        {
          "baseCourseID": 1,
          "baseCourseName": "Bangla",
          "coursTypeID": "1"
        },
        {
          "baseCourseID": 2,
          "baseCourseName": "English",
          "coursTypeID": "1"
        },
        {
          "baseCourseID": 17,
          "baseCourseName": "Accounting",
          "coursTypeID": "1"
        },
        {
          "baseCourseID": 25,
          "baseCourseName": "Information and Communication Technology",
          "coursTypeID": "1"
        },
        {
          "baseCourseID": 28,
          "baseCourseName": "Business Organization and Management",
          "coursTypeID": "1"
        }
      ]
    }
    // console.log(body, "cccbody");

    this._dashboardService.SaveCourseCurriculumCollegeForm(body, this.FormParam.selectedInstituteId).subscribe((data: any) =>
    {
      // console.log(data, "data");
      if (data.isError == false)
      {
        this.matSnackBar.open("Course Curriculum Saved", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
        this.stepper.next();
      } else
      {
        this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
          verticalPosition: 'top',
          duration: 2000,
        });
      };
    }, (error: any) =>
    {
      this.errorMessage = error.message;
      this.matSnackBar.open("Couldn't Save Information, Please Try Again", 'Close', {
        verticalPosition: 'top',
        duration: 2000,
      });
      console.log(error, "error");
    });

  }

  logstep1(): void
  {
    // console.log(this.horizontalStepperForm.controls.step1.getRawValue(), 'horizontalStepperForm');
    // console.log( this.horizontalStepperForm.getRawValue(), "horizontalStepperForm" );
    // console.log(this.horizontalStepperForm, "horizontalStepperForm");

    let fmdsds = this.horizontalStepperForm.controls.studentInformation.getRawValue();
    // const asArray = Object.entries(fmdsds);
    // console.log(fmdsds, "fmdsds");
    // delete fmdsds.studentInformation;
    // console.log(fmdsds, 'fmdsds');

    // let fikii = fmdsds.filter(m => !this.allowed.includes(m));
    // console.log(fikii, 'fikii');

    // const { controls.step1, ...employeeRest } = this.horizontalStepperForm;
    // this.stepper.next();
    this.QuotaInvalid =
      this.horizontalStepperForm.controls.studentInformation.get(
        "studentFreedomFighterQuota"
      ).invalid;
    this.GenderInvalid =
      this.horizontalStepperForm.controls.studentInformation.get(
        "studentGender"
      ).invalid;
  }

  logstep2(): void
  {
    // console.log(this.horizontalStepperForm, "horizontalStepperForm");
  }

  logstep3(): void
  {
    // console.log(this.horizontalStepperForm, "horizontalStepperForm");
  }

  logstep4(): void
  {
    // console.log(this.horizontalStepperForm, "horizontalStepperForm");
  }

  checkOk(): void
  {
    // console.log( this.horizontalStepperForm.controls.studentInformation.pristine, "pristine" );
    // console.log( this.horizontalStepperForm.controls.studentInformation.invalid, "invalid" );
  }

  goToNextStep(): void
  {
    this.stepper.next();
  }

  onStudentProfileImageAdded(eventData: any)
  {
    // console.log(eventData, "onStudentProfileImageAdded");
    // console.log([null, undefined].includes(eventData.userImage));
    this.StudentProfileImage = eventData.userImage;
    // this.StudentProfileImage = eventData.userImage || this.FormParam.AutocompleteImage;
    // console.log(this.StudentProfileImage, "  this.StudentProfileImage ");

  }

  onStudentSignImageAdded(eventData: any)
  {
    // console.log(eventData, "onStudentSignImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onFathersInformationImageAdded(eventData: any)
  {
    this.FatherProfileImage = eventData.userImage;
    // console.log(eventData, "onFathersInformationImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onFathersSignImageAdded(eventData: any)
  {
    // console.log(eventData, "onFathersSignImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onMothersInformationImageAdded(eventData: any)
  {
    this.MotherProfileImage = eventData.userImage;
    // console.log(eventData, "onMothersInformationImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onMothersSignImageAdded(eventData: any)
  {
    // console.log(eventData, "onMothersSignImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onLocalGuardiansInformationImageAdded(eventData: any)
  {
    this.LocalGuardianProfileImage = eventData.userImage;
    // console.log(eventData, "onLocalGuardiansInformationImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onLocalGuardiansInformationSignImageAdded(eventData: any)
  {
    // console.log(eventData, "onMothersSignImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  onDefencesInformationImageAdded(eventData: any)
  {
    // console.log(eventData, "onDefencesInformationImageAdded");
    // console.log([null, undefined].includes(eventData.image));
  }

  CloseStepperForm()
  {
    // this.closeStepper.emit({
    //   close: false,
    // });
    this._router.navigateByUrl("/dashboard");
    localStorage.removeItem("InsType");
  }

  toDataURL(url, callback)
  {
    var xhr = new XMLHttpRequest();
    xhr.onload = function ()
    {
      var reader = new FileReader();
      reader.onloadend = function ()
      {
        callback(reader.result);
      };
      reader.readAsDataURL(xhr.response);
    };
    xhr.open("GET", url, true)
    xhr.responseType = "blob";
    xhr.send();
  }


}

interface spf
{
  userFilename?: any,
  userBase64File?: any,
}
