import { Directive, HostListener, Input } from "@angular/core";
import { AbstractControl } from "@angular/forms";

@Directive({
    selector: "[appMaxLength]"
})
export class MaxLengthDirective {
    @Input() appMaxLength: string;

    constructor() { }

    @HostListener("keydown", ["$event"])
    onKeydown(event: KeyboardEvent) {
        const value = (event.target as HTMLInputElement).value;
        const maxLength = parseInt(this.appMaxLength, 10);
        const allowedKeys = [
            "Backspace",
            "Delete",
            "Tab",
            "Escape",
            "Enter",
            "ArrowLeft",
            "ArrowRight"
        ];
        if (value.length >= maxLength && !allowedKeys.includes(event.key)) {
            event.preventDefault();
            event.stopPropagation();
        }
    }
}

@Directive({
    selector: "[appNoExponentNoDecimal]"
})
export class NoExponentNoDecimalDirective {
    constructor() { }

    validate(control: AbstractControl): { [key: string]: any } | null {
        const forbiddenChars = ["e", "."];
        const value = control.value;
        if (value && forbiddenChars.some((char) => value.includes(char))) {
            return { forbiddenChars: true };
        }
        return null;
    }
}
